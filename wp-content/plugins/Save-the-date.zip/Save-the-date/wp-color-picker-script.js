jQuery(document).ready(function($){
    $('.ir').wpColorPicker();
});